package com.example.clinic

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class data : AppCompatActivity() {

    private lateinit var editTextData: EditText
    private lateinit var buttonEdit: Button
    private lateinit var buttonSave: Button
    private lateinit var btnreturn: Button


    private var isEditable: Boolean = false
    private val sharedPrefFile = "com.example.yourapp.PREFERENCE_FILE_KEY"

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data) // Reference the data.xml layout

        editTextData = findViewById(R.id.editTextData)
        buttonEdit = findViewById(R.id.buttonEdit)
        buttonSave = findViewById(R.id.buttonSave)
        btnreturn = findViewById(R.id.btnreturn)



        // Load saved data
        loadData()

        buttonEdit.setOnClickListener {
            isEditable = !isEditable
            editTextData.isEnabled = isEditable
            buttonEdit.text = if (isEditable) "Stop Editing" else "Edit"
        }

        buttonSave.setOnClickListener {
            val data = editTextData.text.toString()
            saveData(data)
            Toast.makeText(this, "Data Saved: $data", Toast.LENGTH_SHORT).show()
        }
        btnreturn.setOnClickListener {
            val intent = Intent(this, personalinfo::class.java)
            startActivity(intent)
        }

        // Optional: Add a TextWatcher to handle changes in EditText
        editTextData.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                buttonSave.isEnabled = s.toString().isNotEmpty()
            }
        })
    }

    private fun saveData(data: String) {
        val sharedPreferences = getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("savedData", data)
        editor.apply() // Save changes asynchronously
    }

    private fun loadData() {
        val sharedPreferences = getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)
        val savedData = sharedPreferences.getString("savedData", "")
        editTextData.setText(savedData) // Set the loaded data to EditText
    }
}