package com.example.clinic

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class map : AppCompatActivity(), OnMapReadyCallback {
    private var mGoogleMap: GoogleMap? = null
    private var mGoogleMap2: GoogleMap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_map)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mGoogleMap = googleMap
        mGoogleMap2 = googleMap

        val germanUniversityLocation = LatLng(29.985310, 31.438704) //

        // Add a marker at the specified location
        googleMap.addMarker(MarkerOptions().position(germanUniversityLocation).title("GUC clinic"))

        // Move the camera to the specified location
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(germanUniversityLocation, 15f))

        val pharmacy = LatLng(29.982803, 31.441151) //

        // Add a marker at the specified location
        googleMap.addMarker(MarkerOptions().position(pharmacy).title("pharmacy"))

        // Move the camera to the specified location
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(pharmacy, 15f))
    }
}