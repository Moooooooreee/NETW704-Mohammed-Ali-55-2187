package com.example.milestone1.m2

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.milestone1.R
import com.example.milestone1.Review
import com.example.milestone1.User
import com.example.milestone1.fragment.AddMedication
import com.example.milestone1.fragment.ApprovalRequestsFragment
import com.example.milestone1.fragment.DisplayMedication
import com.google.android.material.tabs.TabLayout

class Doctor : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor)

        val mTabLayout: TabLayout = findViewById(R.id.tablayout)
        val fragmentContainer: FrameLayout = findViewById(R.id.fragment_container)

        // Initially set the fragment container visibility to GONE
        fragmentContainer.visibility = View.GONE

        // Add a listener to handle tab selections
        mTabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                // Make sure the FrameLayout is visible when a tab is selected
                fragmentContainer.visibility = View.VISIBLE

                // Replace the fragment based on the tab selected
                when (tab?.position) {
                    0 -> {
                        // Show the Medications fragment when the "Medications" tab is selected
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fragment_container, DisplayMedication())  // Your AddMedication fragment
                            .addToBackStack(null)
                            .commit()
                    }
                    1 -> {
                        // Show the Review fragment when the "Review" tab is selected
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fragment_container, Review())  // Your Reviews fragment
                            .addToBackStack(null)
                            .commit()
                    }
                    2 -> {
                        // Show the Profile fragment when the "Approval" tab is selected
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fragment_container, ApprovalRequestsFragment())  // Your Profile fragment
                            .addToBackStack(null)
                            .commit()
                    }
                    3 -> {
                        // Show the Profile fragment when the "Profile" tab is selected
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fragment_container, User())  // Your Profile fragment
                            .addToBackStack(null)
                            .commit()
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // Optional: Handle tab unselected if needed
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                // Optional: Handle tab reselection if needed
            }
        })

        // Optional: Automatically select the first tab on launch
        mTabLayout.getTabAt(0)?.select()
    }
}
