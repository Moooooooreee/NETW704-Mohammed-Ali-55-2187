package com.example.milestone1.models

enum class ApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class Approval(
    val id: String = "",
    val medicationId: String = "",  // Change from Long to String if it's stored as a string in Firebase
    val patientId: String = "",
    val patientname: String = "",
    val medicationName: String = "",
    val status: String = ApprovalStatus.PENDING.name
) {
    // Convert the string status to ApprovalStatus enum when reading the data
    fun getStatusEnum(): ApprovalStatus {
        return try {
            ApprovalStatus.valueOf(status)
        } catch (e: IllegalArgumentException) {
            ApprovalStatus.PENDING // Default to PENDING if status is invalid
        }
    }
}
