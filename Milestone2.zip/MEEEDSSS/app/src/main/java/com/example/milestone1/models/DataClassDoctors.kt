package com.example.milestone1.models

data class DataClassDoctors(
    val name: String? = null,
    val email: String? = null,
    val password: String? = null,
    val typeuser: Char = 'D',
    var gender: Char? = null,
    var questions: MutableList<String> = mutableListOf(),  // Array of questions
    var responses: MutableList<String> = mutableListOf(),
    var notification: Boolean = false,
    var pending: Boolean = false
)
