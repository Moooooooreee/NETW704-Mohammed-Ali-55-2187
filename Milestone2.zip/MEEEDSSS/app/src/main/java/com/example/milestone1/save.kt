package com.example.milestone1

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class save : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val entries = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_save)

        // Find views by ID
        listView = findViewById(R.id.listView)
        val entryEditText: EditText = findViewById(R.id.entryEditText)
        val saveButton: Button = findViewById(R.id.saveButton)

        // Initialize ArrayAdapter with a simple layout for displaying the list items
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, entries)

        // Set adapter to the ListView
        listView.adapter = adapter

        // Handle Save button click
        saveButton.setOnClickListener {
            val entryText = entryEditText.text.toString()

            // Check if the input is not empty
            if (entryText.isNotEmpty()) {
                // Add new entry to the list
                entries.add(entryText)

                // Notify the adapter that the data has changed so the ListView will update
                adapter.notifyDataSetChanged()

                // Clear the EditText field
                entryEditText.text.clear()

                // Scroll to the bottom of the ListView
                listView.smoothScrollToPosition(entries.size - 1)
            }
        }
    }
}
