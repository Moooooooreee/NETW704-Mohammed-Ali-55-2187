package com.example.milestone1.models

data class Consultation(
    val id: String = "",
    val patientId: String = "",
    val doctorId: String = "",
    val message: String = "",
    val reply: String = "",
    val timestamp: Long = 0L,
    var patientName: String = "" // Add this field for the sender's name
) {
    val status: String
        get() = if (reply.isEmpty()) "Pending" else "Completed"
}
