package com.example.milestone1.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.milestone1.R
import com.example.milestone1.models.Approval

class ApprovalRequestsAdapter(
    private val approvalList: List<Approval>,
    private val onDecision: (Approval, Boolean) -> Unit
) : RecyclerView.Adapter<ApprovalRequestsAdapter.ApprovalViewHolder>() {

    class ApprovalViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val medName: TextView = view.findViewById(R.id.medName)
        val patientName: TextView = view.findViewById(R.id.patientName)
        val approveButton: Button = view.findViewById(R.id.approveButton)
        val rejectButton: Button = view.findViewById(R.id.rejectButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ApprovalViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_approval_request, parent, false)
        return ApprovalViewHolder(view)
    }

    override fun onBindViewHolder(holder: ApprovalViewHolder, position: Int) {
        val approval = approvalList[position]
        holder.medName.text = approval.medicationName
        holder.patientName.text = approval.patientname

        holder.approveButton.setOnClickListener { onDecision(approval, true) }
        holder.rejectButton.setOnClickListener { onDecision(approval, false) }
    }

    override fun getItemCount(): Int = approvalList.size
}
