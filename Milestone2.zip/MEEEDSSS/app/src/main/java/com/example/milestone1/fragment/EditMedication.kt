package com.example.milestone1.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.milestone1.R
import com.example.milestone1.models.Medication
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class EditMedication : Fragment() {

    private lateinit var editTextName: EditText
    private lateinit var editTextPrice: EditText
    private lateinit var editTextQuantity: EditText
    private lateinit var buttonSave: Button
    private lateinit var editTextProductImage: ImageView

    private lateinit var database: DatabaseReference
    private lateinit var storageRef: StorageReference
    private lateinit var medication: Medication
    private var imageUri: Uri? = null
    private var cameraPhotoPath: String? = null

    private val PICK_IMAGE_REQUEST = 1
    private val CAMERA_IMAGE_REQUEST = 2

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_edit_medication, container, false)

        // Initialize views
        editTextName = view.findViewById(R.id.editTextMedicationName)
        editTextPrice = view.findViewById(R.id.editTextMedicationPrice)
        editTextQuantity = view.findViewById(R.id.editTextMedicationQuantity)
        buttonSave = view.findViewById(R.id.buttonSaveMedication)
        editTextProductImage = view.findViewById(R.id.editTextProductImage)

        // Initialize Firebase references
        database = FirebaseDatabase.getInstance().getReference("Medications")
        storageRef = FirebaseStorage.getInstance().getReference("Medications")

        // Get the medication object passed from DisplayMedication
        medication = arguments?.getParcelable("medication") ?: return view

        // Load medication data into fields
        loadMedicationData()

        // Set click listener for the image view to open options (Gallery/Camera)
        editTextProductImage.setOnClickListener {
            showImageSourceOptions()
        }

        buttonSave.setOnClickListener {
            saveMedicationData()
        }

        return view
    }

    private fun loadMedicationData() {
        // Load existing image into ImageView using Glide
        if (!medication.imageUri.isNullOrEmpty()) {
            Glide.with(this)
                .load(medication.imageUri) // Load the image URL
                .into(editTextProductImage)
        }

        // Set text fields with current medication details
        editTextName.setText(medication.name)
        editTextPrice.setText(medication.price.toString())
        editTextQuantity.setText(medication.quantity.toString())
    }

    private fun showImageSourceOptions() {
        // Show dialog to choose between camera and gallery
        val options = arrayOf("Take Photo", "Choose from Gallery")
        AlertDialog.Builder(requireContext())
            .setTitle("Select Image Source")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> openCameraForImage()  // Open Camera
                    1 -> openGalleryForImage() // Open Gallery
                }
            }
            .show()
    }

    private fun openGalleryForImage() {
        val intent = Intent(Intent.ACTION_PICK).apply {
            type = "image/*"
        }
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    private fun openCameraForImage() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        // Ensure there's a camera app to handle the intent
        if (intent.resolveActivity(requireActivity().packageManager) != null) {
            try {
                val photoFile = createImageFile()
                val photoUri = FileProvider.getUriForFile(
                    requireContext(),
                    "${requireContext().packageName}.provider",
                    photoFile
                )
                cameraPhotoPath = photoFile.absolutePath
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
                startActivityForResult(intent, CAMERA_IMAGE_REQUEST)
            } catch (ex: IOException) {
                Toast.makeText(context, "Error creating image file: ${ex.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "No Camera app found.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createImageFile(): File {
        // Create an image file name
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = requireActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timestamp}_", ".jpg", storageDir)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                PICK_IMAGE_REQUEST -> {
                    data?.data?.let { uri ->
                        imageUri = uri
                        editTextProductImage.setImageURI(uri)
                    }
                }
                CAMERA_IMAGE_REQUEST -> {
                    cameraPhotoPath?.let { path ->
                        imageUri = Uri.fromFile(File(path))
                        editTextProductImage.setImageURI(imageUri)
                    }
                }
            }
        }
    }

    private fun saveMedicationData() {
        val name = editTextName.text.toString()
        val price = editTextPrice.text.toString().toDoubleOrNull()
        val quantity = editTextQuantity.text.toString().toIntOrNull()

        if (name.isEmpty() || price == null || quantity == null) {
            Toast.makeText(context, "Please fill all fields correctly.", Toast.LENGTH_SHORT).show()
            return
        }

        // Update the medication object with new values
        medication.name = name
        medication.price = price
        medication.quantity = quantity

        // Persist the image URI if a new one was selected
        if (imageUri != null) {
            medication.imageUri = imageUri.toString()
        }

        // Save updated medication to the database
        database.child(medication.id ?: return).setValue(medication)
            .addOnSuccessListener {
                Toast.makeText(context, "Medication updated successfully.", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack() // Navigate back to the previous screen
            }
            .addOnFailureListener {
                Toast.makeText(context, "Failed to update medication: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
