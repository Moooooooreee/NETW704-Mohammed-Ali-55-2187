package com.example.milestone1.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.milestone1.R
import com.example.milestone1.adapters.MedicationAdapter
import com.example.milestone1.models.Medication
import com.google.firebase.database.*

//displays a list of medications in a RecyclerView
// It integrates Firebase to fetch and manage data and uses the MedicationAdapter to display items

class DisplayMedication : Fragment() {

    private lateinit var database: DatabaseReference //Firebase Realtime Database node for medications
    private lateinit var medicationAdapter: MedicationAdapter
    private val medicationList = mutableListOf<Medication>() //list of medications fetched from Firebase

    //fragment_medications layout (recyclerview) and initialize components
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_medications, container, false)

        //initialize Firebase Database reference (node)
        database = FirebaseDatabase.getInstance().getReference("Medications")

        //set up RecyclerView for displaying medication items
        val recyclerView = view.findViewById<RecyclerView>(R.id.medicationRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        //binds medicationList to the adapter
        medicationAdapter = MedicationAdapter(
            medications = medicationList,
            onActionClick = { medication, action ->
                when (action) {
                    MedicationAdapter.Action.EDIT -> editMedication(medication)
                    MedicationAdapter.Action.DELETE -> deleteMedication(medication)
                }
            },
            //opens the AddMedication fragment
            onAddMedicationClick = {
                openAddMedicationFragment()
            }
        )
        recyclerView.adapter = medicationAdapter

        //opens the AddMedication fragment lama ados 3la el plus icon
        val plusIcon = view.findViewById<View>(R.id.plus)
        plusIcon.setOnClickListener {
            openAddMedicationFragment()
        }

        //fetch data from Firebase
        fetchMedications()

        return view
    }

    private fun fetchMedications() {
        database.addValueEventListener(object : ValueEventListener { //receive events about data changes
            //clears the current list (medicationList)
            //Iterates through Firebase snapshots converting each to a Medication object
            //Updates the medicationList
            override fun onDataChange(snapshot: DataSnapshot) {
                medicationList.clear()
                for (medicationSnapshot in snapshot.children) {
                    val medication = medicationSnapshot.getValue(Medication::class.java)
                    if (medication != null) {
                        medicationList.add(medication)
                    }
                }
                medicationAdapter.notifyDataSetChanged() //ensure RecyclerView refreshes
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Failed to fetch medications: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    //Opens the EditMedication fragment passing the selected Medication object
    private fun editMedication(medication: Medication) {
        val editMedicationFragment = EditMedication()
        //Creates a Bundle to store the Medication object (must implement Parcelable)
        //where parcelable haga zay el intent but for dataclasses, passing data
        val bundle = Bundle()
        bundle.putParcelable("medication", medication) //Pass the medication object
        editMedicationFragment.arguments = bundle

        //replace cureent fragment with the edit medication
        //fragment_container is created in doctor layout for viewing fragments
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, editMedicationFragment)
            .addToBackStack(null)
            .commit()
    }

    //deletes the selected Medication from Firebase
    //removes the medication node using its id
    private fun deleteMedication(medication: Medication) {
        database.child(medication.id ?: return).removeValue()
            .addOnSuccessListener {
                Toast.makeText(context, "Medication deleted successfully.", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(context, "Failed to delete medication: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }

    //opens up addmedication fragment
    private fun openAddMedicationFragment() {
        val addMedicationFragment = AddMedication()
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, addMedicationFragment)
            .addToBackStack(null)
            .commit()
    }
}
