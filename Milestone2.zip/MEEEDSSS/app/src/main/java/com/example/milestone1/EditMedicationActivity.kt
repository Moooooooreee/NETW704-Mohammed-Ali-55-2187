package com.example.milestone1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class EditMedicationActivity : AppCompatActivity() {

    private lateinit var editTextProductName: EditText
    private lateinit var editTextProductPrice: EditText
    private lateinit var editTextProductQuantity: EditText
    private lateinit var editTextProductImage: EditText
    private lateinit var saveButton: Button

    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_medication)

        // Initialize views
        editTextProductName = findViewById(R.id.editTextProductName)
        editTextProductPrice = findViewById(R.id.editTextProductPrice)
        editTextProductQuantity = findViewById(R.id.editTextProductQuantity)
        editTextProductImage = findViewById(R.id.editTextProductImage)
        saveButton = findViewById(R.id.saveButton)

        // Initialize Firebase Database reference
        database = FirebaseDatabase.getInstance().reference

        // Get the medication ID passed from the MedicationAdapter
        val medicationId = intent.getStringExtra("MEDICATION_ID")

        if (medicationId != null) {
            loadMedicationData(medicationId)
        }

        // Handle save button click
        saveButton.setOnClickListener {
            medicationId?.let { id ->
                saveMedicationData(id)
            }
        }
    }

    private fun loadMedicationData(medicationId: String) {
        database.child("medications").child(medicationId).get().addOnSuccessListener { dataSnapshot ->
            if (dataSnapshot.exists()) {
                val name = dataSnapshot.child("name").getValue(String::class.java)
                val price = dataSnapshot.child("price").getValue(Double::class.java)
                val quantity = dataSnapshot.child("quantity").getValue(Int::class.java)
                val imageUrl = dataSnapshot.child("imageUrl").getValue(String::class.java)

                // Set values to edit texts
                editTextProductName.setText(name)
                editTextProductPrice.setText(price?.toString())
                editTextProductQuantity.setText(quantity?.toString())
                editTextProductImage.setText(imageUrl)
            } else {
                Toast.makeText(this, "Medication data not found", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveMedicationData(medicationId: String) {
        val name = editTextProductName.text.toString()
        val price = editTextProductPrice.text.toString()
        val quantity = editTextProductQuantity.text.toString()
        val imageUrl = editTextProductImage.text.toString()

        if (name.isEmpty() || price.isEmpty() || quantity.isEmpty() || imageUrl.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val medicationUpdates = mapOf<String, Any?>(
            "name" to name,
            "price" to price.toDouble(),
            "quantity" to quantity.toInt(),
            "imageUrl" to imageUrl
        )

        database.child("medications").child(medicationId).updateChildren(medicationUpdates)
            .addOnSuccessListener {
                Toast.makeText(this, "Medication updated successfully", Toast.LENGTH_SHORT).show()
                finish() // Close the activity
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error updating medication", Toast.LENGTH_SHORT).show()
            }
    }
}
