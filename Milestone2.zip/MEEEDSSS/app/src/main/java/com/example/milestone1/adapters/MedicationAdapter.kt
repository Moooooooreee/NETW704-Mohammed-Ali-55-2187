package com.example.milestone1.adapters

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.milestone1.R
import android.util.Log
import com.bumptech.glide.Glide
import com.example.milestone1.models.Medication

//el adapter dah by link ma3 el recyclerview 3ashan yeban el adwya
//b el details bt3tha (name,quantity,price,image) + edit w delete functions

//bind data to the recyclerview
class MedicationAdapter(
    private val medications: List<Medication>, // list of medication to be displayed
    private val onActionClick: (Medication, Action) -> Unit, //ma3mol ll edit w el delete
    private val onAddMedicationClick: () -> Unit
) : RecyclerView.Adapter<MedicationAdapter.MedicationViewHolder>() {

    //enum is a predefined in kotlin to store named constant values
    //w deih el edit w el delete is possible actions ll medication
    enum class Action { EDIT, DELETE }

    //ids mn el item_medication bageeb el ids to link
    inner class MedicationViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView? = view.findViewById(R.id.productName)
        val quantity: TextView? = view.findViewById(R.id.productQuantity)
        val price: TextView? = view.findViewById(R.id.productPrice)
        val editButton: ImageView? = view.findViewById(R.id.edit)
        val deleteButton: ImageView? = view.findViewById(R.id.delete)
        val image: ImageView? = view.findViewById(R.id.productImage)

        //bygeeb error message if any view fails to initialize aw lw el esm msh mowgood
        init {
            // Log if any views are missing or not found
            if (name == null) Log.e("MedicationAdapter", "Product name view is null")
            if (quantity == null) Log.e("MedicationAdapter", "Product quantity view is null")
            if (price == null) Log.e("MedicationAdapter", "Product price view is null")
            if (editButton == null) Log.e("MedicationAdapter", "Edit button view is null")
            if (deleteButton == null) Log.e("MedicationAdapter", "Delete button view is null")
            if (image == null) Log.e("MedicationAdapter", "Image view is null")
        }
    }

    //returns MedicationViewHolder aka recyclerview
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicationViewHolder {
        //item_medication layout
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_medication, parent, false)
        return MedicationViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicationViewHolder, position: Int) {
        //binds the data from the medications list to the views
        val medication = medications[position]

        //bind data to views
        holder.name?.text = medication.name
        holder.quantity?.text = "Quantity: ${medication.quantity}"
        holder.price?.text = "Price: $${medication.price}"

        //If imageUri is available, it uses Glide to load the image.
        //glide is a library made for image loading
        //implemented fe el gradle
        if (!medication.imageUri.isNullOrEmpty()) {
            holder.image?.let { imageView ->
                Glide.with(holder.itemView.context)
                    .load(medication.imageUri) //Load image from Firebase
                    .placeholder(R.drawable.loading) //Placeholder image bt show lw hya loading
                    .error(R.drawable.errorimage) //Shown if the image fails to load
                    .into(imageView) // Use let to ensure non-null ImageView
            }
        } else {
            holder.image?.setImageResource(R.drawable.loading) //If no image URI is provided, a default loading image is displayed.
        }


        // Set click listeners for buttons
        holder.editButton?.setOnClickListener {
            if (holder.name != null && holder.quantity != null && holder.price != null) {
                onActionClick(medication, Action.EDIT)
            } else {
                Log.e("MedicationAdapter", "One or more views are null during Edit button click")
            }
        }

        holder.deleteButton?.setOnClickListener {
            if (holder.name != null && holder.quantity != null && holder.price != null) {
                onActionClick(medication, Action.DELETE)
            } else {
                Log.e("MedicationAdapter", "One or more views are null during Delete button click")
            }
        }
    }

    //returns the total number of items in the medications list
    override fun getItemCount(): Int = medications.size
}
