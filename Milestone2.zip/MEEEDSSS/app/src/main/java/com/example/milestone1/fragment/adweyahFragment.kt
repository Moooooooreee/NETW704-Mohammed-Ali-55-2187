package com.example.milestone1.fragment

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.milestone1.R
import com.example.milestone1.adapters.CartAdapter
import com.example.milestone1.adapters.MedsAdapter
import com.example.milestone1.models.CartItem
import com.example.milestone1.models.DataClassPatients
import com.example.milestone1.models.Medication
import com.google.firebase.database.*

class adweyahFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MedsAdapter
    private lateinit var cartRecyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter
    private lateinit var totalTextView: TextView
    private lateinit var orderButton: Button

    private lateinit var database: DatabaseReference
    private val medsList = mutableListOf<Medication>() // Use mutable list to fetch from Firebase
    private val cart = mutableListOf<CartItem>()

    // Initialize patient data with real information
    private val patientData = DataClassPatients()

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the fragment layout
        val view = inflater.inflate(R.layout.fragment_adweyah, container, false)

        // Initialize Firebase Database reference for medications
        database = FirebaseDatabase.getInstance().getReference("Medications")

        // Initialize the RecyclerView for medications
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 1)

        // Initialize the adapter
        adapter = MedsAdapter(medsList, patientData) { medication, quantity ->
            addToCart(medication, quantity)
        }
        recyclerView.adapter = adapter

        // Initialize the RecyclerView for the cart
        cartRecyclerView = view.findViewById(R.id.cartRecyclerView)
        cartRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        cartAdapter = CartAdapter(cart) { cartItem ->
            removeFromCart(cartItem)
        }
        cartRecyclerView.adapter = cartAdapter

        totalTextView = view.findViewById(R.id.totalTextView)
        orderButton = view.findViewById(R.id.orderButton)

        orderButton.setOnClickListener { placeOrder() }

        updateTotalPrice() // Initialize total price

        // Fetch medications from Firebase
        fetchMedications()

        return view
    }

    private fun fetchMedications() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                medsList.clear() // Clear the current list
                for (medicationSnapshot in snapshot.children) {
                    val medication = medicationSnapshot.getValue(Medication::class.java)
                    if (medication != null) {
                        medsList.add(medication) // Add medication to the list
                    }
                }
                adapter.notifyDataSetChanged() // Notify adapter to refresh the displayed items
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to fetch medications: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun addToCart(medication: Medication, quantity: Int) {
        if (quantity > 0) {
            val existingItem = cart.find { it.medication.id == medication.id }
            if (existingItem != null) {
                existingItem.quantity += quantity // Update quantity if already in cart
            } else {
                cart.add(CartItem(medication, quantity)) // Add new item to cart
            }
            updateTotalPrice() // Update total price
            cartAdapter.notifyDataSetChanged() // Notify cart adapter of data change
        } else {
            Toast.makeText(requireContext(), "Please enter a valid quantity", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateTotalPrice() {
        val total = cart.sumOf { it.medication.price * it.quantity }
        totalTextView.text = "Total: $${"%.2f".format(total)}"
    }

    private fun removeFromCart(cartItem: CartItem) {
        cart.remove(cartItem) // Remove item from cart
        updateTotalPrice() // Update total price
        cartAdapter.notifyDataSetChanged() // Notify adapter of data change
    }

    private fun placeOrder() {
        if (cart.isNotEmpty()) {
            // Prepare order summary
            val orderSummary = StringBuilder("Order Summary:\n")
            for (item in cart) {
                orderSummary.append("${item.medication.name} (x${item.quantity}) - $${item.medication.price * item.quantity}\n")
            }
            orderSummary.append("Total: $${"%.2f".format(cart.sumOf { it.medication.price * it.quantity })}")

            // Show confirmation dialog
            AlertDialog.Builder(requireContext())
                .setTitle("Confirm Order")
                .setMessage(orderSummary.toString())
                .setPositiveButton("Confirm") { _, _ ->
                    Toast.makeText(requireContext(), "Order placed successfully!", Toast.LENGTH_SHORT).show()
                    clearCart() // Clear cart after placing order
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            Toast.makeText(requireContext(), "Cart is empty!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearCart() {
        cart.clear() // Clear the cart
        updateTotalPrice() // Update total price
        cartAdapter.notifyDataSetChanged() // Notify adapter of data change
    }
}