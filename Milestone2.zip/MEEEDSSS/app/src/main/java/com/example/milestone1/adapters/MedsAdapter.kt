package com.example.milestone1.adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.milestone1.R
import com.example.milestone1.models.Approval
import com.example.milestone1.models.ApprovalStatus
import com.example.milestone1.models.DataClassPatients
import com.example.milestone1.models.Medication
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MedsAdapter(
    private val medsList: List<Medication>,
    private val patient: DataClassPatients,
    private val onAddToCart: (Medication, Int) -> Unit
) : RecyclerView.Adapter<MedsAdapter.MedsViewHolder>() {

    private val database = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()

    class MedsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val medName: TextView = view.findViewById(R.id.medName)
        val medPrice: TextView = view.findViewById(R.id.medPrice)
        val quantityInput: EditText = view.findViewById(R.id.quantityInput)
        val addButton: Button = view.findViewById(R.id.addButton)
        val approvalButton: Button = view.findViewById(R.id.approvalButton)
        val medImage: ImageView = view.findViewById(R.id.medImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedsViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.meditem, parent, false)
        return MedsViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedsViewHolder, position: Int) {
        val medication = medsList[position]
        holder.medName.text = medication.name
        holder.medPrice.text = "$${medication.price}"

        if (!medication.imageUri.isNullOrEmpty()) {
            holder.medImage?.let { imageView ->
                Glide.with(holder.itemView.context)
                    .load(medication.imageUri) //Load image from Firebase
                    .placeholder(R.drawable.loading) //Placeholder image bt show lw hya loading
                    .error(R.drawable.errorimage) //Shown if the image fails to load
                    .into(imageView) // Use let to ensure non-null ImageView
            }
        } else {
            holder.medImage?.setImageResource(R.drawable.loading) //If no image URI is provided, a default loading image is displayed.
        }

        // Initially hide quantity input, add button, and approval button
        holder.quantityInput.visibility = View.GONE
        holder.addButton.visibility = View.GONE
        holder.approvalButton.visibility = View.GONE

        // Expand/collapse on item click
        holder.itemView.setOnClickListener {
            val isExpanded = holder.quantityInput.visibility == View.VISIBLE

            holder.quantityInput.visibility = if (isExpanded) View.GONE else View.VISIBLE
            holder.addButton.visibility = if (isExpanded) View.GONE else View.VISIBLE
            holder.approvalButton.visibility = if (isExpanded) View.GONE else View.VISIBLE

            // Animate the height change
            val newHeight = if (isExpanded) 50.dpToPx(holder.itemView.context) else ViewGroup.LayoutParams.WRAP_CONTENT
            holder.itemView.layoutParams.height = newHeight
            holder.itemView.requestLayout()
        }

        holder.approvalButton.setOnClickListener {
            val currentUser = auth.currentUser
            if (currentUser == null) {
                Snackbar.make(
                    holder.itemView,
                    "User not logged in! Please log in to request approval.",
                    Snackbar.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            val currentUserId = currentUser.uid
            val approvalRequestsRef = database.getReference("approvalRequests")
            val approvalRequestId = approvalRequestsRef.push().key

            if (approvalRequestId != null) {
                val approvalRequest = mapOf(
                    "id" to approvalRequestId,
                    "patientId" to currentUserId,
                    "patientName" to patient.name,
                    "medicationId" to medication.id.toString(),
                    "medicationName" to medication.name,
                    "status" to ApprovalStatus.PENDING.name
                )

                approvalRequestsRef.child(approvalRequestId).setValue(approvalRequest)
                    .addOnSuccessListener {
                        Snackbar.make(
                            holder.itemView,
                            "Approval request sent for ${medication.name}",
                            Snackbar.LENGTH_LONG
                        ).show()
                    }
                    .addOnFailureListener {
                        Snackbar.make(
                            holder.itemView,
                            "Failed to send approval request",
                            Snackbar.LENGTH_LONG
                        ).show()
                    }
            }
        }

        holder.addButton.setOnClickListener {
            val currentUser = auth.currentUser
            if (currentUser == null) {
                Snackbar.make(holder.itemView, "User not logged in! Please log in to add items to the cart.", Snackbar.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val currentUserId = currentUser.uid
            val approvalRef = database.getReference("approvalRequests")

            approvalRef.orderByChild("patientId").equalTo(currentUserId)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            val approvals = snapshot.children.mapNotNull {
                                try {
                                    it.getValue(Approval::class.java) // Automatically maps data
                                } catch (e: Exception) {
                                    Log.e("FirebaseError", "Error parsing approval: ${e.message}")
                                    null // Skip invalid entries
                                }
                            }

                            val matchingApproval = approvals.find {
                                it.medicationId == medication.id.toString()  // medication.id should be String if stored as String
                            }

                            if (matchingApproval != null) {
                                when (matchingApproval.getStatusEnum()) {
                                    ApprovalStatus.APPROVED -> {
                                        val quantity = holder.quantityInput.text.toString().toIntOrNull()
                                        if (quantity == null || quantity <= 0) {
                                            Snackbar.make(
                                                holder.itemView,
                                                "Enter a valid quantity",
                                                Snackbar.LENGTH_SHORT
                                            ).show()
                                            return
                                        }
                                        onAddToCart(medication, quantity)
                                        holder.quantityInput.text.clear()
                                        Snackbar.make(
                                            holder.itemView,
                                            "${medication.name} added to cart",
                                            Snackbar.LENGTH_LONG
                                        ).show()
                                    }
                                    else -> {
                                        Snackbar.make(
                                            holder.itemView,
                                            "Approval is pending or rejected. Please check with your doctor.",
                                            Snackbar.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            } else {
                                Snackbar.make(
                                    holder.itemView,
                                    "No approval found for this medication. Please check with your doctor.",
                                    Snackbar.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            Snackbar.make(
                                holder.itemView,
                                "No approval requests found for the current user.",
                                Snackbar.LENGTH_LONG
                            ).show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.e("FirebaseError", "Error fetching approvals: ${error.message}")
                        Snackbar.make(
                            holder.itemView,
                            "Error retrieving approval status. Please try again.",
                            Snackbar.LENGTH_LONG
                        ).show()
                    }
                })

        }
    }

    // Function to convert dp to px
    private fun Int.dpToPx(context: Context): Int {
        return (this * context.resources.displayMetrics.density).toInt()
    }

    override fun getItemCount() = medsList.size
}
