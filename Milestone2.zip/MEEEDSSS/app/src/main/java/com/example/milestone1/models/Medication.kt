package com.example.milestone1.models

import android.os.Parcel
import android.os.Parcelable

data class Medication(
    var id: String? = null,  // Firebase key (id)
    var name: String = "",
    var quantity: Int = 0,
    var price: Double = 0.0,
    var imageUri: String? = null  // Image URI (can be used to load images from Firebase storage)
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readDouble(),
        parcel.readString() // For the imageUri
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(name)
        parcel.writeDouble(price)
        parcel.writeInt(quantity)
        parcel.writeString(imageUri)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Medication> {
        override fun createFromParcel(parcel: Parcel): Medication {
            return Medication(parcel)
        }

        override fun newArray(size: Int): Array<Medication?> {
            return arrayOfNulls(size)
        }
    }
}
