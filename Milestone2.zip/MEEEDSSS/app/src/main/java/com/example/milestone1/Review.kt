package com.example.milestone1

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.milestone1.adapters.ConsultationAdapter
import com.example.milestone1.databinding.FragmentReviewBinding
import com.example.milestone1.models.Consultation
import com.google.firebase.database.*

class Review : Fragment() {
    private var _binding: FragmentReviewBinding? = null
    private val binding get() = _binding!!
    private lateinit var database: DatabaseReference
    private val consultations = mutableListOf<Consultation>()
    private lateinit var adapter: ConsultationAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = FirebaseDatabase.getInstance().reference
        binding.rvConsultations.layoutManager = LinearLayoutManager(context)

        // Initialize adapter
        adapter = ConsultationAdapter(consultations, true) { consultation, reply ->
            database.child("consultations").child(consultation.id).child("reply").setValue(reply)
                .addOnSuccessListener {
                    Toast.makeText(context, "Reply sent", Toast.LENGTH_SHORT).show()
                    consultations.remove(consultation)
                    adapter.notifyDataSetChanged()
                }
                .addOnFailureListener {
                    Toast.makeText(context, "Failed to send reply", Toast.LENGTH_SHORT).show()
                }
        }
        binding.rvConsultations.adapter = adapter

        val doctorId = "doctor1" // Replace with dynamic doctor ID if needed

        // Fetch consultations and include the patient name
        database.child("consultations").orderByChild("doctorId").equalTo(doctorId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    consultations.clear()
                    val userDatabase = database.child("Users")
                    for (consultationSnapshot in snapshot.children) {
                        val consultation = consultationSnapshot.getValue(Consultation::class.java)
                        if (consultation != null && consultation.reply.isEmpty()) {
                            // Fetch patient name
                            userDatabase.child(consultation.patientId).child("name")
                                .addListenerForSingleValueEvent(object : ValueEventListener {
                                    override fun onDataChange(userSnapshot: DataSnapshot) {
                                        consultation.patientName =
                                            userSnapshot.getValue(String::class.java) ?: "Unknown"
                                        consultations.add(consultation)
                                        adapter.notifyDataSetChanged()
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                                    }
                                })
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
