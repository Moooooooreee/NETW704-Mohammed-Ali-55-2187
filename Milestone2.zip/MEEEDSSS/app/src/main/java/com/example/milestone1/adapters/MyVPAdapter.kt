package com.example.milestone1.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.milestone1.fragment.AddMedication
import com.example.milestone1.fragment.DisplayMedication
import com.example.milestone1.Review
import com.example.milestone1.User
import com.example.milestone1.fragment.ApprovalRequestsFragment

class MyVPAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    override fun getItemCount(): Int {
        return 4
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> DisplayMedication()
            1 -> Review()
            2 -> ApprovalRequestsFragment()
            3 -> User()
            else -> throw IllegalArgumentException("Invalid position")
        }
    }
}
